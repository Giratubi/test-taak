/**
 * @docid
 * @namespace DevExpress
 * @public
 */
export default class EndpointSelector {
    constructor(options: any);
    /**
     * @docid
     * @publicName urlFor(key)
     * @public
     */
    urlFor(key: string): string;
}
