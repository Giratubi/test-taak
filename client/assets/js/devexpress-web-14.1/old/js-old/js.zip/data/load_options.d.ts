import { LoadOptions as BaseLoadOptions } from './index';

/** @deprecated Use LoadOptions from 'devextreme/data' instead */
export interface LoadOptions extends BaseLoadOptions { }
