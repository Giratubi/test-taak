// eslint-disable-next-line no-restricted-imports
import angular from 'angular';
let ngModule = {};
if(angular) {
    ngModule = angular.module('dx', []);
}
export default ngModule;
