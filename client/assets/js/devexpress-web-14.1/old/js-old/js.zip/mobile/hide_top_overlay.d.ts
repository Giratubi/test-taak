/**
 * @docid
 * @publicName hideTopOverlay()
 * @return Boolean
 * @namespace DevExpress
 * @public
 */
export default function hideTopOverlay(): boolean;
