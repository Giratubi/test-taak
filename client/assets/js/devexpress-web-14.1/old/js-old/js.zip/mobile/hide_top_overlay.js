import { hideCallback } from './hide_callback';

export default function() {
    return hideCallback.fire();
}
