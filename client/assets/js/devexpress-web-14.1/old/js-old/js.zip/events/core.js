/**
* @name UI Events
* @publicName UI Events
* @namespace DevExpress
*/
