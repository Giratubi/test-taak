import MemorizedCallbacks from '../../core/memorized_callbacks';

export default new MemorizedCallbacks();
