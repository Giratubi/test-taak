export const name = 'dxclick';
