export { setTemplateEngine as default } from './templates/template_engine_registry';
