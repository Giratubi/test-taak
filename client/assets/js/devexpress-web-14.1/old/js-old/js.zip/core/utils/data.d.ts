export function getPathParts(name: string): string[];
export function compileGetter(expr: string): unknown;
export function compileSetter(expr: string): unknown;
