import MemorizedCallbacks from './memorized_callbacks';

export default new MemorizedCallbacks();
