export const version = '%VERSION%';
