export class TemplateManager {
  anonymousTemplateName: string;
  addDefaultTemplates(templates: Record<string, unknown>): void;
}
